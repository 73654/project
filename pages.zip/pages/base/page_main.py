# -------------------------------------------------------------------------
# Project: dogdog-ui
# Author: songjianfeng
# Date: 2025/3/25 18:01
# Description:
# -------------------------------------------------------------------------

from common import dog,ui
from pages.base.page import BasePage
from common.ui import find_area_image, Template, get_vertical_rect, touch_and_wait
from common.ui import DeviceType
from common.utils import auto_screenshot

class BasePageMain(BasePage):
    """首页"""
    page_name = "首页"

    @staticmethod
    def _real_click(name):
        pass

    @classmethod
    def _base_click(cls, name):
        with dog.step(f"f{cls.page_name}-点击{name}"):
            cls._real_click(name)
            cls.wait_for_enter()

    @classmethod
    def tab_dynamic(cls):
        """动态"""
        cls._base_click("动态")

    @classmethod
    def tab_friends(cls):
        """好友"""
        cls._base_click("好友")

    @classmethod
    def tab_workbench(cls):
        """工作台"""
        cls._base_click("工作台")

    @classmethod
    def tab_message(cls):
        """消息"""
        cls._base_click("消息")

    @classmethod
    def tab_mine(cls):
        """我的"""
        cls._base_click("我的")

    @classmethod
    @auto_screenshot("登录页面截图")  # 添加自动截图装饰器
    def login(cls):
        """登录"""
        with dog.step(f"{cls.page_name}-进入登录页面"):
            if ui.current_device_type == DeviceType.Android:
                find_area_image(Template("tpl1753166724548.png"), target_rect=(0.26, 0.53, 0.7, 0.7), click=True, timeout=1000)
            else:
                assert_true(False, f"在区域：{rect}图片{path}中，未找到对应图片{source.filepath}")
            cls.wait_for_enter()
